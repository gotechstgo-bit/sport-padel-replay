plugins {
    id("com.android.application")
}

android {
    namespace = "com.gotech.sportpadel"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gotech.sportpadel"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
