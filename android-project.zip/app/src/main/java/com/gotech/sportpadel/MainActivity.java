package com.gotech.sportpadel;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION = 100;
    private TextureView preview;
    private TextView report;
    private LinearLayout cameraButtons;
    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private String pendingCameraId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        buildUi();
        preview.setSurfaceTextureListener(surfaceListener);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        } else {
            scanCameras();
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.rgb(8, 13, 24));

        preview = new TextureView(this);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 2f);
        root.addView(preview, previewParams);

        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(18, 14, 18, 14);
        side.setBackgroundColor(Color.rgb(21, 27, 47));
        root.addView(side, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        TextView title = new TextView(this);
        title.setText("Sport & Padel — Teste nativo de lentes");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setPadding(0,0,0,10);
        side.addView(title);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        cameraButtons = new LinearLayout(this);
        cameraButtons.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(cameraButtons);
        side.addView(hsv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button scan = makeButton("Atualizar diagnóstico");
        scan.setOnClickListener(v -> scanCameras());
        side.addView(scan);

        ScrollView scroll = new ScrollView(this);
        report = new TextView(this);
        report.setTextColor(Color.rgb(220, 230, 245));
        report.setTextSize(13);
        report.setPadding(8, 12, 8, 12);
        scroll.addView(report);
        side.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(29, 38, 64));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(5, 5, 5, 5);
        b.setLayoutParams(p);
        return b;
    }

    private void scanCameras() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        StringBuilder out = new StringBuilder();
        cameraButtons.removeAllViews();
        try {
            String[] ids = cameraManager.getCameraIdList();
            out.append("Câmeras diretamente abertas pelo Camera2: ").append(ids.length).append("\n\n");
            String firstBack = null;
            int n = 1;
            for (String id : ids) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                Set<String> physical = c.getPhysicalCameraIds();
                int[] capabilities = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                boolean logical = contains(capabilities, CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA);

                String side = facingName(facing);
                if (firstBack == null && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) firstBack = id;

                out.append(n++).append(". ID lógico: ").append(id).append("\n")
                        .append("   Lado: ").append(side).append("\n")
                        .append("   Distâncias focais: ").append(focal == null ? "não informado" : Arrays.toString(focal)).append(" mm\n")
                        .append("   Multi-câmera lógica: ").append(logical ? "SIM" : "NÃO").append("\n")
                        .append("   IDs físicos vinculados: ").append(physical.isEmpty() ? "nenhum" : physical).append("\n");

                if (!physical.isEmpty()) {
                    for (String physicalId : physical) {
                        try {
                            CameraCharacteristics pc = cameraManager.getCameraCharacteristics(physicalId);
                            float[] pf = pc.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                            out.append("      ↳ Física ").append(physicalId)
                                    .append(" | focal ").append(pf == null ? "?" : Arrays.toString(pf)).append(" mm\n");
                        } catch (Exception e) {
                            out.append("      ↳ Física ").append(physicalId).append(" | detalhes bloqueados pelo fabricante\n");
                        }
                    }
                }
                out.append("\n");

                Button b = makeButton(side + " " + id + " " + focalLabel(focal));
                final String cameraId = id;
                b.setOnClickListener(v -> openCamera(cameraId));
                cameraButtons.addView(b);
            }
            if (ids.length == 0) out.append("Nenhuma câmera foi disponibilizada pelo Camera2.\n");
            out.append("COMO INTERPRETAR:\n")
                    .append("• Focal menor normalmente significa campo de visão mais amplo.\n")
                    .append("• Se houver vários IDs traseiros, teste cada botão.\n")
                    .append("• Se houver IDs físicos vinculados, o aparelho possui conjunto multi-câmera, mas o fabricante pode impedir a abertura direta de cada lente.\n");
            report.setText(out.toString());
            if (firstBack != null && preview.isAvailable()) openCamera(firstBack);
        } catch (CameraAccessException e) {
            report.setText("Erro Camera2: " + e.getMessage());
        }
    }

    private boolean contains(int[] values, int wanted) {
        if (values == null) return false;
        for (int value : values) if (value == wanted) return true;
        return false;
    }

    private String facingName(Integer facing) {
        if (facing == null) return "desconhecida";
        if (facing == CameraCharacteristics.LENS_FACING_BACK) return "Traseira";
        if (facing == CameraCharacteristics.LENS_FACING_FRONT) return "Frontal";
        if (facing == CameraCharacteristics.LENS_FACING_EXTERNAL) return "Externa";
        return "desconhecida";
    }

    private String focalLabel(float[] values) {
        if (values == null || values.length == 0) return "";
        float min = values[0];
        for (float value : values) min = Math.min(min, value);
        return String.format(Locale.US, "(%.2fmm)", min);
    }

    private void openCamera(String id) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        if (!preview.isAvailable()) {
            pendingCameraId = id;
            return;
        }
        closeCamera();
        try {
            cameraManager.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    cameraDevice = camera;
                    createPreview();
                }
                @Override public void onDisconnected(CameraDevice camera) { camera.close(); }
                @Override public void onError(CameraDevice camera, int error) {
                    camera.close();
                    runOnUiThread(() -> report.append("\nFalha ao abrir câmera " + id + ": erro " + error));
                }
            }, null);
        } catch (Exception e) {
            report.append("\nFalha ao abrir " + id + ": " + e.getMessage());
        }
    }

    private void createPreview() {
        try {
            SurfaceTexture texture = preview.getSurfaceTexture();
            if (texture == null || cameraDevice == null) return;
            texture.setDefaultBufferSize(1920, 1080);
            Surface surface = new Surface(texture);
            CaptureRequest.Builder builder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(surface);
            cameraDevice.createCaptureSession(Collections.singletonList(surface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    captureSession = session;
                    try {
                        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                        session.setRepeatingRequest(builder.build(), null, null);
                    } catch (CameraAccessException e) {
                        report.append("\nErro no preview: " + e.getMessage());
                    }
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    report.append("\nNão foi possível configurar o preview.");
                }
            }, null);
        } catch (CameraAccessException e) {
            report.append("\nErro ao criar preview: " + e.getMessage());
        }
    }

    private void closeCamera() {
        if (captureSession != null) { captureSession.close(); captureSession = null; }
        if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; }
    }

    private final TextureView.SurfaceTextureListener surfaceListener = new TextureView.SurfaceTextureListener() {
        @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            if (pendingCameraId != null) {
                String id = pendingCameraId; pendingCameraId = null; openCamera(id);
            } else scanCameras();
        }
        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { closeCamera(); return true; }
        @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) scanCameras();
        else report.setText("Permissão da câmera negada.");
    }

    @Override protected void onPause() { closeCamera(); super.onPause(); }
}
